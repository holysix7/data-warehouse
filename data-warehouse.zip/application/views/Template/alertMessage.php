<div class="col-md-6">
    <?php echo $this->session->flashdata('alert_message') ?>
</div>